<?php 
include("./include/header.php");
?>

    <section class="flex blog-section1">
        <div class="b-content">
            <p class="cat">CATEGORY</p>
            <H2>LOREM IPSM DOLOR SITAMET</H2>
            <P>orem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh</P>
            <a href="">
                GO TO PROGRAM
            </a>
        </div>
        <div class="b-image"></div>
    </section>


    <section class="blogs">
        <div class="flex blog">
            <img src="./assests/innovation-1.jpg" alt="" srcset="">
            <span>Category</span>
            <H2>LOREM IPSM DOLOR SITAMET</H2>
            <P>orem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh</P>
            <a href="">
                GO TO PROGRAM
            </a>
        </div>
        <div class="flex blog">
            <img src="./assests/Shaza_Article_Pic.jpg" alt="" srcset="">
            <span>Category</span>
            <H2>LOREM IPSM DOLOR SITAMET</H2>
            <P>orem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh</P>
            <a href="">
                GO TO PROGRAM
            </a>
        </div>
        <div class="flex blog">
            <img src="./assests/spain-top-country-for-entrepreneurship.jpg" alt="" srcset="">
            <span>Category</span>
            <H2>LOREM IPSM DOLOR SITAMET</H2>
            <P>orem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh</P>
            <a href="">
                GO TO PROGRAM
            </a>
        </div>
        <div class="flex blog">
            <img src="./assests/howtoinnovation_1200xx2716-1530-0-279.jpg" alt="" srcset="">
            <span>Category</span>
            <H2>LOREM IPSM DOLOR SITAMET</H2>
            <P>orem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh</P>
            <a href="">
                GO TO PROGRAM
            </a>
        </div>
    </section>


    <section class="shapes1">
        <img id="circle" src="./assests/circle.png" alt="" srcset="">
        <img id="circle2" src="./assests/circle.png" alt="" srcset="">
        <img id="halfc" src="./assests/halfc.png" alt="" srcset="">
        <img id="halfc2" src="./assests/halfc.png" alt="" srcset="">
        <img id="hex" src="./assests/hex.png" alt="" srcset="">
        <img id="hex2" src="./assests/hex.png" alt="" srcset="">
        <img id="sha" src="./assests/sha.png" alt="" srcset="">
        <img id="sha2" src="./assests/sha.png" alt="" srcset="">
        <img id="square" src="./assests/square.png" alt="" srcset="">
        <img id="square2" src="./assests/square.png" alt="" srcset="">
    </section>
    <section class="shapes3">
        <img id="b_circle" src="./assests/circle.png" alt="" srcset="">
        <img id="b_circle2" src="./assests/circle.png" alt="" srcset="">
        <img id="b_halfc" src="./assests/halfc.png" alt="" srcset="">
        <img id="b_halfc2" src="./assests/halfc.png" alt="" srcset="">
        <img id="b_hex" src="./assests/hex.png" alt="" srcset="">
        <img id="b_hex2" src="./assests/hex.png" alt="" srcset="">
        <img id="b_sha" src="./assests/sha.png" alt="" srcset="">
        <img id="b_sha2" src="./assests/sha.png" alt="" srcset="">
        <img id="b_square" src="./assests/square.png" alt="" srcset="">
        <img id="b_square2" src="./assests/square.png" alt="" srcset="">
    </section>

    <?php 
include("./include/footer.php");
?>




    <script src="./project.js"></script>
</body>

</html>