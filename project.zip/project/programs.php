<?php 
include("./include/header.php");
?>

<style>
    .container {
        width: 90%;
        margin: auto;
    }
</style>

<section class="container">
    <section class="ourpro">
        <div class="pordiv">
            <h1> Anvikshiki </h1>
            <p>Anvikshiki is an initiative by iPe that aims to inspire a grassroots movement of Development in Bihar. This is a 3 week ideas and entrepreneurship program where participants will work together in teams to come up with innovative solutions to help drive development in Bihar.</p>
       </div>
    </section>


    <section class="flex des">
        <div class="p-image"> <img class="img2" src="./assests/11.png" alt="" srcset=""> </div>
        <div class="flex p-content">
            <h2>ANVIKSHIKI</h2>
            <p>Anvikshiki is an initiative by iPe that aims to inspire a grassroots movement of Development in Bihar. This is a 3 week ideas and entrepreneurship program where participants will work together in teams to come up with innova-tive solutions
                to help drive devel-opment in Bihar. A
            </p>
            <a href="">
                
                    GO TO PROGRAM
             
            </a>
        </div>
    </section>


    <section class="flex des">
        <div class="flex p-content p-c2">
            <h2>PROGRAM 1</h2>
            <p>Anvikshiki is an initiative by iPe that aims to inspire a grassroots movement of Development in Bihar. This is a 3 week ideas and entrepreneurship program where participants will work together in teams to come up with innova-tive solutions
                to help drive devel-opment in Bihar. A
            </p>
            <a href="">
                GO TO PROGRAM
            </a>
        </div>
        <div class="p-image img3"> <img class="img2 l" src="./assests/11.png" alt="" srcset=""> </div>
    </section>


    <section class="flex des">
    <div class="p-image "> <img class="img2" src="./assests/11.png" alt="" srcset=""> </div>
        <div class="flex p-content">
            <h2>ANVIKSHIKI</h2>
            <p>Anvikshiki is an initiative by iPe that aims to inspire a grassroots movement of Development in Bihar. This is a 3 week ideas and entrepreneurship program where participants will work together in teams to come up with innova-tive solutions
                to help drive devel-opment in Bihar. A
            </p>
            <a href="">
                
                    GO TO PROGRAM
             
            </a>
        </div>
    </section>


    <section class="flex des">
        <div class="flex p-content p-c2">
            <h2>PROGRAM 1</h2>
            <p>Anvikshiki is an initiative by iPe that aims to inspire a grassroots movement of Development in Bihar. This is a 3 week ideas and entrepreneurship program where participants will work together in teams to come up with innova-tive solutions
                to help drive devel-opment in Bihar. A
            </p>
            <a href="">
                GO TO PROGRAM
            </a>
        </div>
        <div class="p-image img3"> <img class="img2 l" src="./assests/11.png" alt="" srcset=""> </div>
    </section>

    <section class="shapes2">
        <img id="p_circle" src="./assests/circle.png" alt="" srcset="">
        <img id="p_circle2" src="./assests/circle.png" alt="" srcset="">
        <img id="p_halfc" src="./assests/halfc.png" alt="" srcset="">
        <img id="p_halfc2" src="./assests/halfc.png" alt="" srcset="">
        <img id="p_hex" src="./assests/hex.png" alt="" srcset="">
        <img id="p_hex2" src="./assests/hex.png" alt="" srcset="">
        <img id="p_sha" src="./assests/sha.png" alt="" srcset="">
        <img id="p_sha2" src="./assests/sha.png" alt="" srcset="">
        <img id="p_square" src="./assests/square.png" alt="" srcset="">
        <img id="p_square2" src="./assests/square.png" alt="" srcset="">
    </section>

    <section class="shapes4">
        <img id="p1_circle" src="./assests/circle.png" alt="" srcset="">
        <img id="p1_circle2" src="./assests/circle.png" alt="" srcset="">
        <img id="p1_halfc" src="./assests/halfc.png" alt="" srcset="">
        <img id="p1_halfc2" src="./assests/halfc.png" alt="" srcset="">
        <img id="p1_hex" src="./assests/hex.png" alt="" srcset="">
        <img id="p1_hex2" src="./assests/hex.png" alt="" srcset="">
        <img id="p1_sha" src="./assests/sha.png" alt="" srcset="">
        <img id="p1_sha2" src="./assests/sha.png" alt="" srcset="">
        <img id="p1_square" src="./assests/square.png" alt="" srcset="">
        <img id="p1_square2" src="./assests/square.png" alt="" srcset="">
    </section>

    </section>

    <?php 
include("./include/footer.php");
?>



    <script src="./project.js"></script>
</body>

</html>