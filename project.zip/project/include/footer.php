<section class="footer">

<div class="footer-div1">
    <h2>About</h2>
    <p>Aspiring to inculcate collaborative and outcome oriented work culture.</p>
</div>



<div class="footer-div2">
    <h2>Contact us</h2>
    <h4>Phone</h4>
    <p>+91-920405 8755</p>
    <h4>E-mail</h4>
    <p>ipebiharoffice@gmail.com</p>
</div>



<div class="footer-div3">
<h2>Our office</h2>
    <h4>Head Office</h4>
    <p>D-24, Vatika Green City, Dimna Road, Mango, East Singhbhum, Jamshedpur-831012</p>
    <h4>Patna Office</h4>
    <p>Shadwal, Vijaynagar, Rukanpura, Patna-800014</p>
</div>


<div class="footer-div4">
    <a href="">
        <i class="fa-brands fa-facebook-square"></i>
</a>
    <a href="">
        <i class="fa-brands fa-linkedin"></i>
</a>
    <a href="">
        <i class="fa-brands fa-youtube"></i>
</a>
</div>


</section>

<section class="footer2">
    <div>
        <h4>Copyright © 2022</h4>
    </div>
    <div>
        <h4>Powered By <span class="color-r">IPE</span> </h4>
    </div>
    <div>
        <h4>Designed By <span> <a href="http://mrashwani.com" target="_blank" rel="noopener noreferrer" class="color-r"> Ashwani</a></span> </h4>
    </div>
</section>